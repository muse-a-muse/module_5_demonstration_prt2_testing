# Module 05 Demonstration Part 2

## Description
Introduction to Unit Testing

## Author
Student Name

## Demonstration Topics
- Unit Testing
- Benefits of Unit Testing
- Directory Structure for Source Code and Tests
- Naming Conventions for Tests
- Writing and Running Tests
- Organizing Tests
- Testing Edge Cases
- Testing with Mock Objects
- Testing Exceptions
